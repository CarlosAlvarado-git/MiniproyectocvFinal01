Docker Hub(https://hub.docker.com/repository/docker/carlosalvaradodock/micvfinal01)
'RUN'
    'docker run -i -t -p 5000:5000 carlosalvaradodock/micvfinal01'
